from django.test import TestCase

# Create your tests here.
# inventory/tests.py
from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from .models import Item

class ItemAPITestCase(APITestCase):
    def setUp(self):
        self.item_data = {'name': 'Item 1', 'description': 'Description 1', 'price': 100.00, 'stock': 50}
        self.item = Item.objects.create(**self.item_data)
    
    def test_create_item(self):
        url = reverse('item-list')
        response = self.client.post(url, self.item_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_get_item(self):
        url = reverse('item-detail', args=[self.item.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_update_item(self):
        url = reverse('item-detail', args=[self.item.id])
        updated_data = {'name': 'Item 1 Updated', 'description': 'Description 1', 'price': 120.00, 'stock': 30}
        response = self.client.put(url, updated_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_delete_item(self):
        url = reverse('item-detail', args=[self.item.id])
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

