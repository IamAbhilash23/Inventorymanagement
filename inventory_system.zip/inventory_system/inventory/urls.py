from django.urls import path
from .views import create_item  # Import your view
from .views import get_item
from .views import update_item,delete_item,register,login_user


urlpatterns = [
    path('items/', create_item, name='create_item'),  # Create Item URL
]
urlpatterns += [
    path('items/<int:item_id>/', get_item, name='get_item'),
]
urlpatterns += [
    path('items/<int:item_id>/', update_item, name='update_item'),
]
urlpatterns += [
    path('items/<int:item_id>/', delete_item, name='delete_item'),
]
urlpatterns += [
    path('register/', register, name='register'),
]
urlpatterns += [
    path('login/', login_user, name='login_user'),
]
